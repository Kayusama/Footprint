import 'package:flutter/material.dart';
import 'package:footprint3/auth_helper.dart';
import 'package:footprint3/database_helper.dart';
import 'package:footprint3/homepage.dart';
import 'package:footprint3/resetpassword_page.dart';
import 'package:footprint3/signup_page.dart';
import 'HolderTracker_class.dart';
import 'utils.dart';

import 'package:firebase_auth/firebase_auth.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final AuthHelper _authHelper = AuthHelper();

  @override
  void initState() {
    super.initState();
    getUser();
  }

  void getUser() {
    User? user = FirebaseAuth.instance.currentUser;
    
    if (user != null) {
      try {
        getTracker(user.uid).then((tracker) {
          if (tracker != null) {
            curTracker = tracker;
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (context) => DocumentTrackingScreen()),
            );
            print("User found: ${tracker.username}");
          } else {
            print("User not found in the database.");
          }
        });
      } catch (e) {
        print("Error fetching user: $e");
      }
      print("User ID: ${user.uid}");
      print("Email: ${user.email}");
      print("Display Name: ${user.displayName}");
    } else {
      print("No user is currently signed in.");
    }
  }

  Future<void> _login() async {
    try {
    String username = _usernameController.text.trim();
    String password = _passwordController.text.trim();
    List<HolderTracker> allTrackers = await getAllTrackers();
    HolderTracker tracker1 = HolderTracker.empty();
    if (allTrackers.isNotEmpty) {
      for (var tracker in allTrackers) {
        if (tracker.username == username) {
          tracker1 = tracker;
        }
      }
      if(tracker1.email!=""){
        String uid = await _authHelper.login(tracker1.email, password);
        if (uid != '') {
          curTracker = tracker1;
          Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (context) => DocumentTrackingScreen()),
            );
        } else {
          AlertDialogHelper.showAlertDialog(context, "Wrong email or password.");
        }
      }
      else {
        String uid = await _authHelper.login(username, password);
        if (uid != '') {

          curTracker = (await getTracker(uid))!;
          Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (context) => DocumentTrackingScreen()),
            );
        } else {
          AlertDialogHelper.showAlertDialog(context, "Wrong email or password.");
        }
        AlertDialogHelper.showAlertDialog(context, "No user found with this username.");
      }
    }
    else {
      AlertDialogHelper.showAlertDialog(context, "No users found."); 
    }
  } catch (e) {
    AlertDialogHelper.showAlertDialog(context, e.toString());
  }
    }

  @override
Widget build(BuildContext context) {
  return Scaffold(
    backgroundColor: backgroundColor,
    resizeToAvoidBottomInset: true, // Allow automatic resizing
    body: SafeArea(
      child: SingleChildScrollView(
        keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
        child: Padding(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(context).viewInsets.bottom, // Push content up
          ),
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                _buildLoginForm(),
              ],
            ),
          ),
        ),
      ),
    ),
  );
}


  Widget _buildLoginForm() {
    return SizedBox(
      width: 400,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          const SizedBox(height: 100),
          Padding(
            padding: EdgeInsets.all(10),
            child: Text(
              "Login",
              style: TextStyle(
                fontFamily: 'Roboto', // Custom font
                fontSize: 40,
                fontWeight: FontWeight.w100, // Thinnest weight
                color: mainOrange,
              ),
            ),

          ),
          // SvgPicture.asset(
          //   'images/undraw_around_the_world_re_rb1p 2.svg',
          //   width: 250,
          //   height: 250,
          // ),
          SizedBox(height: 200,),
          CustomTextField(
            controller: _usernameController,
            labelText: 'Username',
          ),
          SizedBox(height: 20,),
          CustomTextField(
            controller: _passwordController,
            labelText: 'Password',
            password: true,
          ),
          const SizedBox(height: 40),
          _buildLoginButton(),
          SizedBox(
            width: 300,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const ResetpasswordPage()),
                    );
                  },
                  child: Text(
        'Forgot password',
        style: TextStyle(
      color: mainOrange,
      fontSize: 12,
      fontWeight: FontWeight.bold,
        ),
      ),
      
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          _buildSignUpButton(),
        ],
      ),
    );
  }

  

  

  Widget _buildLoginButton() {
    return Container(
      width: 300,
      margin: const EdgeInsets.all(10),
      child: ElevatedButton(
        onPressed: () {
          _login();
          // Navigator.push(
          //   context,
          //   MaterialPageRoute(builder: (context) => DocumentTrackingScreen()),
          // );
        },
        style: ButtonStyle(
          backgroundColor: WidgetStateProperty.all<Color>(
            mainOrange,
          ),
        ),
        child: const Text(
          'Login',
          style: TextStyle(
            fontSize: 25,
            color: Colors.white,
            fontWeight: FontWeight.bold,

          ),
        ),
      ),
    );
  }

  Widget _buildSignUpButton() {
  return Container(
  width: 300,
  margin: const EdgeInsets.all(10),
  child: ElevatedButton(
    onPressed: () {
     Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const SignupPage()),
      );
    },
    style: ElevatedButton.styleFrom(
      backgroundColor: const Color.fromARGB(255, 217, 217, 217), // background color
    ),
    child: Text(
      'Sign up',
      style: TextStyle(
        fontSize: 25,
        color: mainOrange,

      ),
    ),
  ),
);
}
}