import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:footprint3/DocumentDetailsPage.dart';
import 'package:footprint3/TrackableDocument_class.dart';
import 'package:footprint3/database_helper.dart';
import 'package:footprint3/HolderTracker_class.dart';
import 'package:footprint3/utils.dart';

class HoldingsPage extends StatefulWidget {
  @override
  _HoldingsPageState createState() => _HoldingsPageState();
}

class _HoldingsPageState extends State<HoldingsPage> {
  late Future<List<TrackableDocument>> _onHoldDocumentsFuture;
  late Future<List<TrackableDocument>> _forwardedDocumentsFuture;
  late Future<List<TrackableDocument>> _toReceiveDocumentsFuture;
  late Future<List<TrackableDocument>> _cancelledDocumentsFuture;

  @override
  void initState() {
    super.initState();
    _onHoldDocumentsFuture = _fetchDocumentsByStatus(DocumentStatus.onHold);
    _forwardedDocumentsFuture = _fetchDocumentsByStatus(DocumentStatus.forwarded);
    _toReceiveDocumentsFuture = getToReceive();
    _cancelledDocumentsFuture = _fetchDocumentsByStatus(DocumentStatus.cancelled);
  }

  Future<List<TrackableDocument>> _fetchDocumentsByStatus(DocumentStatus status) async {
    List<TrackableDocument> documents = await getDocumentsByStatus(status);
    return documents;
  }

  Future<List<TrackableDocument>> getDocumentsByStatus(DocumentStatus status) {
    return getHoldersDocuments().then((documents) {
      return documents.where((doc) => doc.status == status).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 4,
      child: Scaffold(
        appBar: AppBar(
        backgroundColor: mainOrange,
        title: const Text("Holdings",
            style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
      
          bottom: TabBar(
            labelColor: Colors.white,
            unselectedLabelColor: Colors.black,
            indicatorColor: Colors.white,
            tabs: [
              Tab(text: 'OnHold'),
              Tab(text: 'Forwarded'),
              Tab(text: 'To receive'),
              Tab(text: 'Cancelled'),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            FutureBuilder<List<TrackableDocument>>(
              future: _onHoldDocumentsFuture,
              builder: (context, snapshot) {
                return HoldingsList(snapshot: snapshot);
              },
            ),
            FutureBuilder<List<TrackableDocument>>(
              future: _forwardedDocumentsFuture,
              builder: (context, snapshot) {
                return HoldingsList(snapshot: snapshot);
              },
            ),
            FutureBuilder<List<TrackableDocument>>(
              future: _toReceiveDocumentsFuture,
              builder: (context, snapshot) {
                return HoldingsList(snapshot: snapshot);
              },
            ),
            FutureBuilder<List<TrackableDocument>>(
              future: _cancelledDocumentsFuture,
              builder: (context, snapshot) {
                return HoldingsList(snapshot: snapshot);
              },
            ),
          ],
        ),
      ),
    );
  }
}

class HoldingsList extends StatelessWidget {
  final AsyncSnapshot<List<TrackableDocument>> snapshot;

  HoldingsList({required this.snapshot});

  @override
  Widget build(BuildContext context) {
    if (snapshot.connectionState == ConnectionState.waiting) {
      return Center(child: CircularProgressIndicator());
    } else if (snapshot.hasError) {
      return Center(child: Text('Error loading documents'));
    } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
      return Center(child: Text('No documents found'));
    } else {
      List<TrackableDocument> documents = snapshot.data!;

      return Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount: documents.length,
              itemBuilder: (context, index) {
                final doc = documents[index];
                return GestureDetector(
                  child: Card(
                    margin: EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                    color: Colors.orange[50],
                    child: ListTile(
                      leading: doc.imageBase64List.isNotEmpty &&
                              doc.imageBase64List[0].isNotEmpty
                          ? Card(
                              child: Image.memory(
                                base64Decode(doc.imageBase64List[0]),
                                fit: BoxFit.cover,
                                width: 50,
                                height: 50,
                              ),
                            )
                          : null,
                      title: Text(doc.title),
                      subtitle: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          FutureBuilder<String>(
                            future: _getHolderName(doc),
                            builder: (context, snapshot) {
                              if (snapshot.connectionState == ConnectionState.waiting) {
                                return Text('Current Holder: loading...');
                              } else if (snapshot.hasError) {
                                return Text('Current Holder: error');
                              } else {
                                return Text('Current Holder: ${snapshot.data}');
                              }
                            },
                          ),
                          if (doc.status == DocumentStatus.forwarded)
                            FutureBuilder<String>(
                              future: _getForwardedToName(doc),
                              builder: (context, snapshot) {
                                if (snapshot.connectionState == ConnectionState.waiting) {
                                  return Text('Forwarded to: loading...');
                                } else if (snapshot.hasError) {
                                  return Text('Forwarded to: error');
                                } else {
                                  return Text('Forwarded to: ${snapshot.data}');
                                }
                              },
                            ),
                        ],
                      ),
                      trailing: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            doc.lastUpdatedDate.toLocal().toString().split(' ')[0],
                            style: TextStyle(fontSize: 12),
                          ),
                          Text(
                            doc.status.toString().split('.').last,
                            style: TextStyle(color: Colors.red, fontSize: 12),
                          ),
                        ],
                      ),
                    ),
                  ),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => DocumentDetailsPage(documentKey: doc.key,
                         
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      );
    }
  }

  Future<String> _getHolderName(TrackableDocument doc) async {
    HolderTracker? tracker = await getTrackerUsingKey(doc.currentHolderKey);
    return tracker?.fullName ?? 'Unknown';
  }

  Future<String> _getForwardedToName(TrackableDocument doc) async {
    String key = doc.records.last.receiverKey ?? '';
    if (key.isNotEmpty) {
      HolderTracker? tracker = await getTrackerUsingKey(key);
      return tracker?.fullName ?? 'Unknown';
    }
    return 'Unknown';
  }
}
