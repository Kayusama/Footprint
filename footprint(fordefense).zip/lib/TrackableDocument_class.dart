// Enum for Document Status
import 'package:footprint3/DocumentRecord_class.dart';
import 'package:footprint3/HolderTracker_class.dart';
import 'package:footprint3/database_helper.dart';

enum DocumentStatus {
  registered,
  onHold,
  forwarded,
  received,
  archived,
  cancelled,
}

enum ScanOptions {
  None,
  OCR,
  qrCode,
  barcode,
}

extension ScanOptionsExtension on ScanOptions {
  String get label {
    switch (this) {
      case ScanOptions.None:
        return "None";
      case ScanOptions.OCR:
        return "OCR";
      case ScanOptions.qrCode:
        return "QR Code";
      case ScanOptions.barcode:
        return "Barcode";
    }
  }
}

extension DocumentStatusExtension on DocumentStatus {
  String get label {
    switch (this) {
      case DocumentStatus.registered:
        return "Registered";
      case DocumentStatus.onHold:
        return "On Hold";
      case DocumentStatus.forwarded:
        return "Forwarded";
      case DocumentStatus.received:
        return "Received";
      case DocumentStatus.archived:
        return "Archived";
      case DocumentStatus.cancelled:
        return "Cancelled";
    }
  }
}

class TrackableDocument {
  String title;
  List<DocumentRecord> records;
  String currentHolderKey;
  DocumentStatus status;
  String type;
  DateTime createdDate;
  DateTime lastUpdatedDate;
  String remarks;
  String key;
  List<String> embeddings;
  List<String> imageBase64List;
  ScanOptions scanOption;
  bool isScanRequiredUponReceiving;
  String scancode;
  int privacy; // ✅ New field

  TrackableDocument({
    required this.title,
    required this.records,
    required this.currentHolderKey,
    required this.status,
    required this.type,
    required this.createdDate,
    required this.lastUpdatedDate,
    required this.remarks,
    required this.key,
    required this.embeddings,
    required this.imageBase64List,
    required this.scanOption,
    required this.isScanRequiredUponReceiving,
    required this.scancode,
    required this.privacy, // ✅ Added to constructor
  });

  TrackableDocument.empty()
      : title = '',
        records = [],
        currentHolderKey = '',
        status = DocumentStatus.onHold,
        type = '',
        createdDate = DateTime.now(),
        lastUpdatedDate = DateTime.now(),
        remarks = '',
        key = '',
        embeddings = [],
        imageBase64List = [],
        scanOption = ScanOptions.OCR,
        isScanRequiredUponReceiving = false,
        scancode = '',
        privacy = 0; // ✅ Default value

  factory TrackableDocument.fromJson(Map<String, dynamic> data) {
    return TrackableDocument(
      title: data['title'] ?? '',
      records: (data['records'] as List<dynamic>?)
              ?.map((record) => DocumentRecord.fromJson(record))
              .toList() ??
          [],
      currentHolderKey: data['currentHolderKey'] ?? '',
      status: DocumentStatus.values.firstWhere(
        (e) => e.name == (data['status'] ?? 'onHold'),
        orElse: () => DocumentStatus.onHold,
      ),
      type: data['type'] ?? '',
      createdDate:
          DateTime.tryParse(data['createdDate'] ?? '') ?? DateTime.now(),
      lastUpdatedDate:
          DateTime.tryParse(data['lastUpdatedDate'] ?? '') ?? DateTime.now(),
      remarks: data['remarks'] ?? '',
      key: data['key'] ?? '',
      embeddings: List<String>.from(data['embeddings'] ?? []),
      imageBase64List: List<String>.from(data['imageBase64List'] ?? []),
      isScanRequiredUponReceiving: data['isScanRequiredUponReceiving'] ?? false,
      scanOption: ScanOptions.values.firstWhere(
        (e) => e.name == (data['scanOptions'] ?? 'OCR'),
        orElse: () => ScanOptions.OCR,
      ),
      scancode: data['scancode'] ?? '',
      privacy: data['privacy'] ?? 0, // ✅ Extract from JSON
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'title': title,
      'records': records.map((record) => record.toJson()).toList(),
      'currentHolderKey': currentHolderKey,
      'status': status.name,
      'type': type,
      'createdDate': createdDate.toIso8601String(),
      'lastUpdatedDate': lastUpdatedDate.toIso8601String(),
      'remarks': remarks,
      'key': key,
      'embeddings': embeddings,
      'imageBase64List': imageBase64List,
      'scanOptions': scanOption.name,
      'isScanRequiredUponReceiving': isScanRequiredUponReceiving,
      'scancode': scancode,
      'privacy': privacy, // ✅ Add to JSON
    };
  }

  set setCurrentHolder(String newHolderKey) {
    records.last.date = DateTime.now();
    records.add(DocumentRecord(
        holder: newHolderKey,
        date: DateTime.now(),
        remarks: remarks,
        status: status));
    currentHolderKey = newHolderKey;
    updateLastModified();
  }

  void updateLastModified() {
    lastUpdatedDate = DateTime.now();
  }

  void forwardDocument(String receiverkey, String remarks) {
    status = DocumentStatus.forwarded;
    records.add(DocumentRecord(
      holder: currentHolderKey,
      receiverKey: receiverkey,
      date: DateTime.now(),
      remarks: remarks,
      status: status,
    ));
    updateLastModified();

    print("Document has been forwarded to $receiverkey.");
  }

  void receivedDocument(String receiverkey, String remarks) {
    status = DocumentStatus.received;
    records.add(DocumentRecord(
      holder: currentHolderKey,
      receiverKey: receiverkey,
      date: DateTime.now(),
      remarks: remarks,
      status: status,
    ));

    currentHolderKey = receiverkey;
    this.remarks = remarks;
    status = DocumentStatus.onHold;


    updateLastModified();

    print("Document has been received by $receiverkey.");
  }

  void cancelTransfer(String remarks) {
  status = DocumentStatus.cancelled; 
  this.remarks = remarks;

  records.add(DocumentRecord(
    holder: currentHolderKey,
    receiverKey: null,
    date: DateTime.now(),
    remarks: remarks,
    status: status,
  ));

  status = DocumentStatus.onHold; 
  updateLastModified();

  print("Document has been cancelled.");
}
}
