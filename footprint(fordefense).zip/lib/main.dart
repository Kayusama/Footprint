import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:footprint3/login_page.dart';
import 'package:footprint3/utils.dart';


void main() async {
  WidgetsFlutterBinding.ensureInitialized(); 

  await Firebase.initializeApp(
      options: const FirebaseOptions(
          apiKey: "AIzaSyCzBKV8nDLfoEW8P-qN8kZQq4vQLKbFsu4",
          authDomain: "footprint-b00bs.firebaseapp.com",
          databaseURL: "https://footprint-b00bs-default-rtdb.asia -southeast1.firebasedatabase.app",
          projectId: "footprint-b00bs",
          storageBucket: "footprint-b00bs.firebasestorage.app",
          messagingSenderId: "688442946572",
          appId: "1:688442946572:web:af2f04c4894873a2212a29"
          ));

  FirebaseMessaging messaging = FirebaseMessaging.instance;
  await messaging.requestPermission();
  NotificationSettings settings = await messaging.getNotificationSettings();
  if (settings.authorizationStatus == AuthorizationStatus.authorized) {
    print('User granted permission');
  } else if (settings.authorizationStatus == AuthorizationStatus.provisional) {
    print('User granted provisional permission');
  } else {
    print('User declined or has not accepted permission');
  }
  // Get device token
  String? token = await messaging.getToken();
  print('FCM Token: $token');

  // Handle foreground messages
  FirebaseMessaging.onMessage.listen((RemoteMessage message) {
    print('Received a message while in foreground!');
    print('Message data: ${message.data.toString()}');
    if (message.notification != null) {
      print('Message also contained a notification: ${message.notification}');
    }
  });

  FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);

  runApp(const MyApp());
}

Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
    await Firebase.initializeApp();
    print('Handling a background message: ${message.messageId}');
  }

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Footprint',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSwatch(
          primarySwatch: Colors.orange,
          backgroundColor: backgroundColor,
        ),
        useMaterial3: true,
      ),
      home: LoginPage(),
    );
  }
}
