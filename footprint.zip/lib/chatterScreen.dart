import 'dart:convert';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:footprint3/HolderTracker_class.dart';
import 'package:footprint3/ProfilePage.dart';
import 'package:footprint3/chat_class.dart';
import 'package:footprint3/database_helper.dart';
import 'package:footprint3/utils.dart';
import '../constants.dart';

late String messageText;

class ChatterScreen extends StatefulWidget {
  @override
  _ChatterScreenState createState() => _ChatterScreenState();
  Chat chat;
  ChatterScreen({required this.chat});
}

class _ChatterScreenState extends State<ChatterScreen> {
  final chatMsgTextController = TextEditingController();
  final _auth = FirebaseAuth.instance;

  @override
  void initState() {
    super.initState();
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.deepPurple),
        elevation: 0,
        bottom: PreferredSize(
          preferredSize: Size(25, 10),
          child: Container(
            child: LinearProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
              backgroundColor: Colors.blue[100],
            ),
            decoration: BoxDecoration(),
            constraints: BoxConstraints.expand(height: 1),
          ),
        ),
        backgroundColor: Colors.white10,
        title: Row(
          children: <Widget>[
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  'Chatter',
                  style: TextStyle(
                      fontFamily: 'Poppins',
                      fontSize: 16,
                      color: Colors.deepPurple),
                ),
                Text('by ishandeveloper',
                    style: TextStyle(
                        fontFamily: 'Poppins',
                        fontSize: 8,
                        color: Colors.deepPurple))
              ],
            ),
          ],
        ),
        actions: <Widget>[
          GestureDetector(
            child: Icon(Icons.more_vert),
          )
        ],
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          ChatStream(chatID: widget.chat.key,),
          Container(
            padding: EdgeInsets.symmetric(vertical: 10, horizontal: 10),
            decoration: kMessageContainerDecoration,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                Expanded(
                  child: Material(
                    borderRadius: BorderRadius.circular(50),
                    color: Colors.white,
                    elevation: 5,
                    child: Padding(
                      padding: const EdgeInsets.only(left: 8.0, top: 2, bottom: 2),
                      child: TextField(
                        onChanged: (value) {
                          messageText = value;
                        },
                        controller: chatMsgTextController,
                        decoration: kMessageTextFieldDecoration,
                      ),
                    ),
                  ),
                ),
                MaterialButton(
                  shape: CircleBorder(),
                  color: Colors.blue,
                  onPressed: () {
                    chatMsgTextController.clear();
                    sendMessage(widget.chat.key, Message(
                      text: messageText, 
                      senderUid: curTracker.uid, 
                      timestamp: DateTime.now(),
                      ));
                  },
                  
                  child: Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Icon(Icons.send, color: Colors.white),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class ChatStream extends StatelessWidget {
  final String chatID;

  ChatStream({required this.chatID});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<DocumentSnapshot>(
      stream: FirebaseFirestore.instance.collection('Chats').doc(chatID).snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return Center(
            child: CircularProgressIndicator(backgroundColor: Colors.deepPurple),
          );
        }

        var chatData = snapshot.data!.data() as Map<String, dynamic>?;

        if (chatData == null || !chatData.containsKey('messages')) {
          return Center(child: Text("No messages yet."));
        }

        List<dynamic> messagesData = chatData['messages'];
        List<MessageBubble> messageWidgets = messagesData.reversed.map((msg) {
          final message = Message.fromMap(msg);
          return MessageBubble(
            message: message,
          );
        }).toList();

        return Expanded(
          child: ListView(
            reverse: true,
            padding: EdgeInsets.symmetric(vertical: 15, horizontal: 10),
            children: messageWidgets,
          ),
        );
      },
    );
  }
}

class MessageBubble extends StatelessWidget {
  final Message message;

  MessageBubble({required this.message});

  bool get isMe => message.senderUid == curTracker.uid;

  Future<HolderTracker> getTrackerFuture() async {
    return await getTracker(message.senderUid) ?? HolderTracker.empty();
  }


  @override
  Widget build(BuildContext context) {
    return FutureBuilder<HolderTracker>(
      future: getTrackerFuture(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return Padding(
            padding: const EdgeInsets.all(12.0),
            child: Text("Loading...", style: TextStyle(fontSize: 13, fontFamily: 'Poppins')),
          );
        }

        HolderTracker tracker = snapshot.data!;

        return Padding(
          padding: const EdgeInsets.all(12.0),
          child: Column(
            crossAxisAlignment:
                isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
            children: <Widget>[
              Container(
                padding: EdgeInsets.symmetric(horizontal: 10),
                child: Text(
                  tracker.username,
                  style: TextStyle(fontSize: 13, fontFamily: 'Poppins', color: Colors.black87),
                ),
              ),
              Row(
                mainAxisAlignment:
                    isMe ? MainAxisAlignment.end : MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [

                isMe
                ? Material(
                  borderRadius: BorderRadius.circular(50),
                  color: isMe ? Colors.blue : Colors.white,
                  elevation: 5,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                    child: Text(
                      message.text,
                      style: TextStyle(
                        color: isMe ? Colors.white : Colors.blue,
                        fontFamily: 'Poppins',
                        fontSize: 15,
                      ),
                    ),
                  ),
                )
                : SizedBox(),

                  GestureDetector(
                  child: CircleAvatar(
                    radius: 20,
                    backgroundImage: (tracker.profilePicture.isNotEmpty)
                        ? MemoryImage(base64Decode(tracker.profilePicture))
                        : null,
                    child: (tracker.profilePicture.isEmpty)
                        ? Text(
                            tracker.username[0],
                            style: TextStyle(
                              color: mainOrange,
                              fontWeight: FontWeight.bold,
                              fontSize: 24,
                            ),
                          )
                        : null,
                  ),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => ProfilePage(user: tracker,)),
                  ),
                ),
                isMe
                ? SizedBox()
                : Material(
                  borderRadius: BorderRadius.circular(50),
                  color: isMe ? Colors.blue : Colors.white,
                  elevation: 5,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                    child: Text(
                      message.text,
                      style: TextStyle(
                        color: isMe ? Colors.white : Colors.blue,
                        fontFamily: 'Poppins',
                        fontSize: 15,
                      ),
                    ),
                  ),
                ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }
}
