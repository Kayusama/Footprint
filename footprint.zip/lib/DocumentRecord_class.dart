import 'TrackableDocument_class.dart';

class DocumentRecord {
  String holder;
  DateTime date; // Keeping this as requested
  DocumentStatus status; // Enum-based status tracking
  String remarks;
  String? receiverKey; // Optional field

  DocumentRecord({
    required this.holder,
    required this.date,
    required this.status,
    required this.remarks,
    this.receiverKey, // Optional receiverKey
  });

  // Convert DocumentRecord to JSON
  Map<String, dynamic> toJson() {
    return {
      'holder': holder,
      'date': date.toIso8601String(),
      'status': status.name, // Store as a string
      'remarks': remarks,
      'receiverKey': receiverKey, // Include receiverKey if not null
    };
  }

  // Create DocumentRecord from JSON
  factory DocumentRecord.fromJson(Map<String, dynamic> data) {
    return DocumentRecord(
      holder: data['holder'] ?? '',
      date: DateTime.tryParse(data['date'] ?? '') ?? DateTime.now(),
      status: DocumentStatus.values.firstWhere(
        (e) => e.name == (data['status'] ?? 'onHold'),
        orElse: () => DocumentStatus.onHold,
      ),
      remarks: data['remarks'] ?? '',
      receiverKey: data['receiverKey'], // Handle optional receiverKey
    );
  }
}
