import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:footprint3/DocumentRecord_class.dart';
import 'package:footprint3/TrackableDocument_class.dart';
import 'package:footprint3/database_helper.dart';
import 'package:footprint3/utils.dart';
import 'package:google_mlkit_document_scanner/google_mlkit_document_scanner.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'package:image_picker/image_picker.dart';

class RegisterdocumentPage extends StatefulWidget {
  @override
  _RegisterdocumentPageState createState() => _RegisterdocumentPageState();
}

class _RegisterdocumentPageState extends State<RegisterdocumentPage> {
  final TextEditingController titleController = TextEditingController();
  final TextEditingController typeController = TextEditingController();
  final TextEditingController remarksController = TextEditingController();

  bool textScanning = false;
  List<XFile> imageFiles = [];
  List<String> scannedText = [];

  @override
  void dispose() {
    titleController.dispose();
    typeController.dispose();
    remarksController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.orange.shade50,
      appBar: AppBar(
        backgroundColor: Colors.orange.shade100,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.orange),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text("Register Document", style: TextStyle(color: Colors.orange)),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            children: [
              SizedBox(height: 40),
              _buildTextField(titleController, "Title"),
              SizedBox(height: 20),
              _buildTextField(typeController, "Type"),
              SizedBox(height: 20),
              _buildTextField(remarksController, "Remarks", maxLines: 5),
              SizedBox(height: 20),
              if (textScanning) CircularProgressIndicator(),
              if (imageFiles.isNotEmpty)
                Column(
                  children: imageFiles.map((file) => Image.file(File(file.path), height: 150)).toList(),
                ),
              SizedBox(height: 10),
              ElevatedButton.icon(
                onPressed: () => scanDocument(),
                icon: Icon(Icons.camera_alt),
                label: Text("Scan Document"),
              ),
              SizedBox(height: 20),
              _buildRegisterButtons(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTextField(TextEditingController controller, String label, {int maxLines = 1}) {
    return TextField(
      controller: controller,
      maxLines: maxLines,
      decoration: InputDecoration(
        labelText: label,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(20),
        ),
      ),
    );
  }

  Widget _buildRegisterButtons() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        ElevatedButton(
          onPressed: registerDocument,
          style: ElevatedButton.styleFrom(backgroundColor: textScanning? Colors.green : Colors.orange ),
          child: Text('Register', style: TextStyle(color: Colors.white),),
        ),
        SizedBox(width: 16),
        OutlinedButton(
          onPressed: () {},
          child: Text('Cancel', style: TextStyle(color: Colors.orange)),
        ),
      ],
    );
  }

  Future<void> scanDocument() async {
    try {
      DocumentScannerOptions documentOptions = DocumentScannerOptions(
        documentFormat: DocumentFormat.jpeg,
        mode: ScannerMode.filter,
        pageLimit: 100, 
        isGalleryImport: true,
      );

      final documentScanner = DocumentScanner(options: documentOptions);
      DocumentScanningResult result = await documentScanner.scanDocument();

      if (result.images.isNotEmpty) {
        for (String imagePath in result.images) {
          setState(() {
            textScanning = true;
            imageFiles.add(XFile(imagePath));
          });
          await getRecognisedText(imagePath);
        }
      }
    } catch (e) {
      print("Error: $e");
      setState(() {
        textScanning = false;
      });
    }
  }

  // void getImage(ImageSource source) async {
  //   try {
  //     final pickedImage = await ImagePicker().pickImage(source: source);
  //     if (pickedImage != null) {
  //       setState(() {
  //         textScanning = true;
  //         imageFiles.add(pickedImage);
  //       });
  //       await getRecognisedText(pickedImage);
  //     }
  //   } catch (e) {
  //     setState(() {
  //       textScanning = false;
  //     });
  //   }
  // }

  Future<void> getRecognisedText(String imagePath) async {
    final inputImage = InputImage.fromFilePath(imagePath);
    final textRecognizer = TextRecognizer();
    final RecognizedText recognizedText = await textRecognizer.processImage(inputImage);
    for (TextBlock block in recognizedText.blocks) {
      for (TextLine line in block.lines) {
        String lineText = line.text.replaceAll(RegExp(r'[^a-zA-Z0-9 ]'), ' ');
        if (lineText.trim().isNotEmpty) {
          scannedText.add(lineText);
        }
      }
    }
    textScanning = false;
    await textRecognizer.close();
    setState(() {});
  }

  Future<void> registerDocument() async {
    List<String> imageBase64List = [];
    for (var file in imageFiles) {
      final bytes = await file.readAsBytes();
      final compressedBytes = await compressAndResizeImage(bytes);
      if (compressedBytes != null) {
        imageBase64List.add(base64Encode(compressedBytes as List<int>));
      }
    }


    DocumentRecord newRecord = DocumentRecord(
      holder: curTracker.key,
      status: DocumentStatus.registered,
      date: DateTime.now(),
      remarks: remarksController.text,
    );

    TrackableDocument newDocument = TrackableDocument(
      title: titleController.text,
      records: [newRecord],
      status: DocumentStatus.onHold,
      type: typeController.text,
      createdDate: DateTime.now(),
      lastUpdatedDate: DateTime.now(),
      remarks: remarksController.text,
      key: '',
      embeddings: scannedText,
      currentHolderKey: curTracker.key,
      imageBase64List: imageBase64List,
    );

    addDocument(newDocument);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Document sent successfully!')),
    );
    Navigator.pop(context);
  }
}
