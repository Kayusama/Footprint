import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:footprint3/DocumentDetailsPage.dart';
import 'package:footprint3/TrackableDocument_class.dart';
import 'package:footprint3/database_helper.dart';

class HoldingsPage extends StatefulWidget {
  @override
  _HoldingsPageState createState() => _HoldingsPageState();
}

class _HoldingsPageState extends State<HoldingsPage> {
  late Future<List<TrackableDocument>> _forwardedDocumentsFuture;
  late Future<List<TrackableDocument>> _toReceiveDocumentsFuture;
  late Future<List<TrackableDocument>> _cancelledDocumentsFuture;

  @override
  void initState() {
    super.initState();
    // Initial fetch of documents for each tab
    _forwardedDocumentsFuture = getDocumentsByStatus(DocumentStatus.forwarded);
    _toReceiveDocumentsFuture = getToReceive();
    _cancelledDocumentsFuture = getDocumentsByStatus(DocumentStatus.cancelled);
  }

  Future<List<TrackableDocument>> getDocumentsByStatus(DocumentStatus status) {
    return getHoldersDocuments().then((documents) {
      return documents.where((doc) => doc.status == status).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.orange[100],
          title: Text(
            'Holdings',
            style: TextStyle(color: Colors.black),
          ),
          leading: IconButton(
            icon: Icon(Icons.arrow_back, color: Colors.black),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
          bottom: TabBar(
            labelColor: Colors.orange,
            unselectedLabelColor: Colors.black,
            indicatorColor: Colors.orange,
            tabs: [
              Tab(text: 'Forwarded'),
              Tab(text: 'To receive'),
              Tab(text: 'Cancelled'),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            // Forwarded Tab
            FutureBuilder<List<TrackableDocument>>(
              future: _forwardedDocumentsFuture,
              builder: (context, snapshot) {
                return HoldingsList(snapshot: snapshot);
              },
            ),
            // To Receive Tab
            FutureBuilder<List<TrackableDocument>>(
              future: _toReceiveDocumentsFuture,
              builder: (context, snapshot) {
                return HoldingsList(snapshot: snapshot);
              },
            ),
            // Cancelled Tab
            FutureBuilder<List<TrackableDocument>>(
              future: _cancelledDocumentsFuture,
              builder: (context, snapshot) {
                return HoldingsList(snapshot: snapshot);
              },
            ),
          ],
        ),
      ),
    );
  }
}

class HoldingsList extends StatelessWidget {
  final AsyncSnapshot<List<TrackableDocument>> snapshot;

  HoldingsList({required this.snapshot});

  @override
  Widget build(BuildContext context) {
    if (snapshot.connectionState == ConnectionState.waiting) {
      return Center(child: CircularProgressIndicator());
    } else if (snapshot.hasError) {
      return Center(child: Text('Error loading documents'));
    } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
      return Center(child: Text('No documents found'));
    } else {
      List<TrackableDocument> documents = snapshot.data!;

      return Column(
        children: [
          Expanded(
            child: documents.isEmpty
                ? Center(child: Text('No documents in this category'))
                : ListView.builder(
                    itemCount: documents.length,
                    itemBuilder: (context, index) {
                      final doc = documents[index];
                      return GestureDetector(
                        child: Card(
                          margin: EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                          color: Colors.orange[50],
                          child: ListTile(
  leading: Card(
    child: Image.memory(
      base64Decode(doc.imageBase64List[index]),
      fit: BoxFit.cover,
    ),
  ),
  title: Text(doc.title),
  subtitle: Column(
    children: [
      FutureBuilder(
        future: getTrackerUsingKey(doc.currentHolderKey),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Text('Loading holder...');
          } else if (snapshot.hasError) {
            return Text('Error fetching holder');
          } else if (!snapshot.hasData) {
            return Text('No holder found');
          } else {
            final tracker = snapshot.data!;
            return Text('Current Holder: ${tracker.username}');
          }
        },
      ),
      if(doc.status == DocumentStatus.forwarded) ...[
        FutureBuilder(
        future: doc.records.last.receiverKey != null 
            ? getTrackerUsingKey(doc.records.last.receiverKey!) 
            : Future.error('Receiver key is null'),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Text('Loading holder...');
          } else if (snapshot.hasError) {
            return Text('Error fetching holder');
          } else if (!snapshot.hasData) {
            return Text('No holder found');
          } else {
            final tracker = snapshot.data!;
            return Text('Forwarded to: ${tracker.username}');
          }
        },
      ),
      ],
    ],
  ),
  trailing: Column(
    mainAxisAlignment: MainAxisAlignment.center,
    children: [
      Text(
        doc.lastUpdatedDate.toLocal().toString().split(' ')[0],
        style: TextStyle(fontSize: 12),
      ),
      Text(
        doc.status.toString().split('.').last,
        style: TextStyle(color: Colors.red, fontSize: 12),
      ),
    ],
  ),
),

                        ),
                        onTap: () {
                          Navigator.push(context, 
                            MaterialPageRoute(
                              builder: (context) => DocumentDetailsPage(
                                document: doc,
                              ),
                            ),
                          );
                        },
                      );
                    },
                  ),
          ),
        ],
      );
    }
  }
}
