import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:footprint3/auth_helper.dart';
import 'package:footprint3/database_helper.dart';
import 'package:footprint3/homepage.dart';
import 'package:footprint3/utils.dart';

import 'HolderTracker_class.dart';

class SignupPage extends StatefulWidget {
  const SignupPage({super.key});

  @override
  State<SignupPage> createState() => _SignupPageState();
}

class _SignupPageState extends State<SignupPage> {
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _confirmPasswordController = TextEditingController();
  final AuthHelper _authHelper = AuthHelper();

  @override
  void initState() {
    super.initState();
  }

  Future<void> _signup() async {
    String email = _emailController.text.trim();
    String username = _usernameController.text.trim();
    String password = _passwordController.text.trim();
    String confirmPassword = _confirmPasswordController.text.trim();

    if (password==confirmPassword) {
      try {
        User? user1 = await _authHelper.signUp(email, password);
        if (user1 != null) {
          curTracker = HolderTracker.empty();
          curTracker.uid = user1.uid;
          curTracker.email = email;
          curTracker.username = username;

          String? curTrackerUid = await addTracker(curTracker);
          curTracker.uid = curTrackerUid!;
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => DocumentTrackingScreen()),
          );
        }
      } catch (e) {
        // AlertDialogHelper.showAlertDialog(context, 'Invalid email or username');
        AlertDialogHelper.showAlertDialog(context, e.toString());

      }
    } else {
      AlertDialogHelper.showAlertDialog(context, 'Password did not matched');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundColor,
      resizeToAvoidBottomInset: true, // Enable automatic resizing
      body: SafeArea(
        child: SingleChildScrollView(
          keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
          child: Padding(
            padding: EdgeInsets.only(
              bottom: MediaQuery.of(context).viewInsets.bottom, // Push content up when keyboard appears
            ),
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  _buildLoginForm(),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }


  Widget _buildLoginForm() {
    return SizedBox(
      width: 400,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          const SizedBox(height: 100),
          Padding(
            padding: const EdgeInsets.all(10),
            child: Text(
              "Sign up",
              style: TextStyle(
                fontFamily: 'Roboto',
                fontSize: 40,
                fontWeight: FontWeight.w100,
                color: mainOrange,
              ),
            ),
          ),
          SizedBox(height: 100),
          CustomTextField(
            controller: _usernameController,
            labelText: 'Username',
          ),
          CustomTextField(
            controller: _emailController,
            labelText: 'Email',
          ),
          CustomTextField(
            controller: _passwordController,
            labelText: 'Password',
            password: true,
          ),
          CustomTextField(
            controller: _confirmPasswordController,
            labelText: 'Confirm Password',
            password: true,
          ),
          const SizedBox(height: 20),
          _buildSignUpButton(),
          const SizedBox(height: 10),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Container(width: 120, height: 2, color: Colors.grey[900]),
              Text(
                "or",
                style: TextStyle(fontSize: 12, color: Colors.grey[900]),
              ),
              Container(width: 120, height: 2, color: Colors.grey[900]),
            ],
          ),
          _buildSigninwithGoogle(),
          _buildSigninwithFacebook(),
        ],
      ),
    );
  }

  Widget _buildSignUpButton() {
    return Container(
      width: 300,
      margin: const EdgeInsets.all(10),
      child: ElevatedButton(
        onPressed: (){
          _signup();
        },
        style: ButtonStyle(
          backgroundColor: WidgetStateProperty.all<Color>(mainOrange),
        ),
        child: Text(
          'Sign up',
          style: TextStyle(
            fontSize: 25,
            color: Colors.white,
            fontWeight: FontWeight.bold,

          ),
        ),
      ),
    );
  }

  Widget _buildSigninwithGoogle() {
    return Container(
      width: 300,
      margin: const EdgeInsets.all(10),
      child: ElevatedButton(
        onPressed: () {
          // Google sign-in logic here
          // _authHelper.signInWithGoogle();
        },
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color.fromARGB(255, 217, 217, 217),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Image.asset('images/843776_google_icon (1).png', height: 30, width: 30),
            SizedBox(width: 10),
            Text(
              'Sign in with Google',
              style: TextStyle(
                fontSize: 20,
                color: mainOrange,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSigninwithFacebook() {
    return Container(
      width: 300,
      margin: const EdgeInsets.all(10),
      child: ElevatedButton(
        onPressed: () {
          // Facebook sign-in logic here
        },
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color.fromARGB(255, 217, 217, 217),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Image.asset('images/211902_social_facebook_icon.png', height: 30, width: 30),
            SizedBox(width: 10),
            Text(
              'Sign in with Facebook',
              style: TextStyle(
                fontSize: 20,
                color: mainOrange,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
