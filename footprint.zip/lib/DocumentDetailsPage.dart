import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:footprint3/SendDocument_page.dart';
import 'package:footprint3/TrackDocumentPage.dart';
import 'package:footprint3/TrackableDocument_class.dart';
import 'package:footprint3/database_helper.dart';
import 'package:footprint3/utils.dart';
import 'package:intl/intl.dart';

class DocumentDetailsPage extends StatefulWidget {
  final TrackableDocument document;

  const DocumentDetailsPage({Key? key, required this.document}) : super(key: key);

  @override
  _DocumentDetailsPageState createState() => _DocumentDetailsPageState();
}

class _DocumentDetailsPageState extends State<DocumentDetailsPage> {
  int currentPage = 0; // Track current image index

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Document Details"),
        backgroundColor: Colors.orange,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Document Title
            Text(
              widget.document.title,
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),

            // Tracking Number
            Text(
              "Tracking Number: ${widget.document.key}",
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
            ),
            const SizedBox(height: 8),

            // Status
            Row(
              children: [
                Text("Status: ", style: TextStyle(fontSize: 16)),
                Chip(
                  label: Text(widget.document.status.label),
                  backgroundColor: Colors.orange[100],
                ),
              ],
            ),
            const SizedBox(height: 8),

            // Current Holder
            FutureBuilder(
            future: getTrackerUsingKey(widget.document.currentHolderKey),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return Text('Loading holder...');
              } else if (snapshot.hasError) {
                return Text('Error fetching holder');
              } else if (!snapshot.hasData) {
                return Text('No holder found');
              } else {
                final tracker = snapshot.data!;
                return Text(
              "Current Holder: ${tracker.username}",
              style: TextStyle(fontSize: 16),
            );
              }
            },
          ),
            if(widget.document.status == DocumentStatus.forwarded) ...[
            FutureBuilder(
            future: widget.document.records.last.receiverKey != null 
                ? getTrackerUsingKey(widget.document.records.last.receiverKey!) 
                : Future.error('Receiver key is null'),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return Text('Loading holder...');
              } else if (snapshot.hasError) {
                return Text('Error fetching holder');
              } else if (!snapshot.hasData) {
                return Text('No holder found');
              } else {
                final tracker = snapshot.data!;
                return Text('Forwarded to: ${tracker.username}', style: TextStyle(fontSize: 16),);
              }
            },
          ),
          ],

          Row(
  mainAxisAlignment: MainAxisAlignment.start,
  children: [
    if(widget.document.status == DocumentStatus.onHold) ...[
      ElevatedButton.icon(
        onPressed: () {
          // Action for first button
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => SendDocumentPage(document: widget.document),
            ),
          );
        },
        icon: Icon(Icons.send, color: Colors.white),
        label: Text('Send', style: TextStyle(color: Colors.white)),
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.orange,
        ),
      ),
    ],
    SizedBox(width: 8,),
    if(widget.document.status == DocumentStatus.forwarded && widget.document.records.last.receiverKey == curTracker.key) ...[
    ElevatedButton.icon(
      onPressed: () {
        // Action for second button
      },
      icon: Icon(Icons.receipt, color: Colors.white),
      label: Text('Receive', style: TextStyle(color: Colors.white)),
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.orange,
      ),
    ),
  ],
  ]
),
          
            const SizedBox(height: 12),

            // Remarks (Optional)
            if (widget.document.remarks.isNotEmpty)
              Text(
                "Remarks: ${widget.document.remarks}",
                style: TextStyle(fontSize: 16, fontStyle: FontStyle.italic),
              ),

            const SizedBox(height: 16),

            // Image Carousel
            if (widget.document.imageBase64List.isNotEmpty)
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(
                    height: 200,
                    child: PageView.builder(
                      itemCount: widget.document.imageBase64List.length,
                      onPageChanged: (index) {
                        setState(() {
                          currentPage = index;
                        });
                      },
                      itemBuilder: (context, index) {
                        return Image.memory(
                          base64Decode(widget.document.imageBase64List[index]),
                          fit: BoxFit.cover,
                        );
                      },
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Text(
                      '${currentPage + 1}/${widget.document.imageBase64List.length}',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                  ),
                ],
              ),

            const SizedBox(height: 16),

            // Records Section Title
            Text(
              "History",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),

            // History List
Expanded(
  child: widget.document.records.isNotEmpty
      ? ListView.builder(
          itemCount: 1, // Only one item
          itemBuilder: (context, index) {
            final latestRecord = widget.document.records.last; // Get the latest (last) record
            return GestureDetector(
              child: Card(
                margin: EdgeInsets.symmetric(vertical: 6),
                elevation: 2,
                child: ListTile(
                  leading: Icon(Icons.history, color: Colors.orange),
                  title: Text(latestRecord.holder),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Status: ${latestRecord.status.label}"),
                      Text(
                        "Date: ${DateFormat('yyyy-MM-dd HH:mm').format(latestRecord.date)}",
                        style: TextStyle(color: Colors.grey[600]),
                      ),
                      if (latestRecord.remarks.isNotEmpty)
                        Text(
                          "Remarks: ${latestRecord.remarks}",
                          style: TextStyle(fontStyle: FontStyle.italic),
                        ),
                    ],
                  ),
                ),
              ),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => TrackDocumentPage(trackableDocument: widget.document),
                  ),
                );
              },
            );
          },
        )
      : Center(
          child: Text(
            "No history records found.",
            style: TextStyle(color: Colors.grey, fontSize: 16),
          ),
        ),
),

          ],
        ),
      ),
    );
  }
}
