import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:footprint3/DocumentRecord_class.dart';
import 'package:footprint3/TrackableDocument_class.dart';
import 'package:footprint3/chat_class.dart';
import 'package:footprint3/utils.dart';
import 'HolderTracker_class.dart';


final FirebaseFirestore firestore = FirebaseFirestore.instance;
final CollectionReference documentsCollection = firestore.collection('Documents');
final CollectionReference trackersCollection = firestore.collection('Trackers');
final CollectionReference chatsCollection = FirebaseFirestore.instance.collection('Chats');

Future<String?> addTracker(HolderTracker tracker) async {
  try {
    DocumentReference docRef = await trackersCollection.add(tracker.toJson());
    await docRef.update({'key': docRef.id}); // Store Firestore-generated ID
    print('Tracker added successfully with ID: ${docRef.id}');
    return docRef.id; // Return the generated ID
  } catch (error) {
    print('Failed to add Tracker: $error');
    return null; // Return null if there was an error
  }
}

Future<void> updateTracker(HolderTracker tracker) async {
  try {
    if (tracker.key.isEmpty) {
      print('Error: Tracker key is null');
      return;
    }
    await trackersCollection.doc(tracker.key).update(tracker.toJson());
    print('Tracker updated successfully');
  } catch (error) {
    print('Failed to update Tracker: $error');
  }
}

Future<List<HolderTracker>> getAllTrackers() async {
  try {
    QuerySnapshot querySnapshot = await trackersCollection.get();
    return querySnapshot.docs
        .map((doc) => HolderTracker.fromJson({
              ...doc.data() as Map<String, dynamic>,
              'key': doc.id,
            }))
        .toList();
  } catch (error) {
    print('Failed to get trackers: $error');
    return [];
  }
}

Future<HolderTracker?> getTrackerUsingKey(String key) async {
  try {
    DocumentSnapshot docSnapshot = await trackersCollection.doc(key).get();

    if (docSnapshot.exists) {
      return HolderTracker.fromJson({
        ...docSnapshot.data() as Map<String, dynamic>,
        'key': docSnapshot.id,
      });
    } else {
      print('Tracker not found for the provided key: $key');
      return null;
    }
  } catch (error) {
    print('Failed to get tracker with key $key: $error');
    return null;
  }
}


Future<void> deleteTracker(String trackerID) async {
  try {
    await trackersCollection.doc(trackerID).delete();
    print('Tracker deleted successfully');
  } catch (error) {
    print('Failed to delete Tracker: $error');
  }
}

Future<HolderTracker?> getTracker(String uid) async {
  try {
    QuerySnapshot querySnapshot =
        await trackersCollection.where('uid', isEqualTo: uid).get();

    if (querySnapshot.docs.isNotEmpty) {
      DocumentSnapshot doc = querySnapshot.docs.first;
      return HolderTracker.fromJson({
        ...doc.data() as Map<String, dynamic>,
        'key': doc.id,
      });
    }
  } catch (error) {
    print('Failed to fetch tracker: $error');
  }
  return null;
}

Future<String?> addDocument(TrackableDocument document) async {
  try {
    // Add the document first
    DocumentReference docRef = await documentsCollection.add(document.toJson());
    await docRef.update({'key': docRef.id});
    print('Document added successfully with ID: ${docRef.id}');
    return docRef.id;
  } catch (error) {
    print('Failed to add Document: $error');
    return null;
  }
}


Future<void> updateDocument(TrackableDocument document) async {
  try {
    if (document.key.isEmpty) {
      print('Error: Document key is null');
      return;
    }
    await documentsCollection.doc(document.key).update(document.toJson());
    print('Document updated successfully');
  } catch (error) {
    print('Failed to update Document: $error');
  }
}

Future<List<TrackableDocument>> getAllDocuments() async {
  try {
    QuerySnapshot querySnapshot = await documentsCollection.get();
    return querySnapshot.docs
        .map((doc) => TrackableDocument.fromJson({
              ...doc.data() as Map<String, dynamic>,
              'key': doc.id,
            }))
        .toList();
  } catch (error) {
    print('Failed to get documents: $error');
    return [];
  }
}

Future<List<TrackableDocument>> getToReceive() async {
  try {
    QuerySnapshot querySnapshot = await documentsCollection.get();

    List<TrackableDocument> allDocuments = querySnapshot.docs.map((doc) {
      return TrackableDocument.fromJson({
        ...doc.data() as Map<String, dynamic>,
        'key': doc.id,
      });
    }).toList();

    // Filter documents based on latest DocumentRecord
    List<TrackableDocument> filteredDocuments = allDocuments.where((document) {
      List<DocumentRecord> records = document.records;
      if (records.isEmpty) return false;
      var latestRecord = records.last;

      return latestRecord.status == DocumentStatus.forwarded &&
             latestRecord.receiverKey == curTracker.key;
    }).toList();

    print("found only ${filteredDocuments.length}");

    return filteredDocuments;
  } catch (error) {
    print('Failed to get documents: $error');
    return [];
  }
}


Future<List<TrackableDocument>> getHoldersDocuments() async {
  try {
    QuerySnapshot querySnapshot = await documentsCollection
        .where('currentHolderKey', isEqualTo: curTracker.key)
        .get();

    return querySnapshot.docs
        .map((doc) => TrackableDocument.fromJson({
              ...doc.data() as Map<String, dynamic>,
              'key': doc.id,
            }))
        .toList();
  } catch (error) {
    print('Failed to get filtered documents: $error');
    return [];
  }
}


Future<void> deleteDocument(String documentID) async {
  try {
    await documentsCollection.doc(documentID).delete();
    print('Document deleted successfully');
  } catch (error) {
    print('Failed to delete Document: $error');
  }
}

Future<TrackableDocument?> getDocument(String trackingNumber) async {
  try {
    QuerySnapshot querySnapshot =
        await documentsCollection.where('trackingNumber', isEqualTo: trackingNumber).get();

    if (querySnapshot.docs.isNotEmpty) {
      DocumentSnapshot doc = querySnapshot.docs.first;
      return TrackableDocument.fromJson({
        ...doc.data() as Map<String, dynamic>,
        'key': doc.id,
      });
    }
  } catch (error) {
    print('Failed to fetch document: $error');
  }
  return null;
}

Future<String?> addChat(Chat chat) async {
  try {
    DocumentReference docRef = await chatsCollection.add(chat.toJson());
    await docRef.update({'key': docRef.id}); // Store Firestore-generated ID
    print('Chat added successfully with ID: ${docRef.id}');

    return docRef.id; // Return the generated ID
  } catch (error) {
    print('Failed to add Chat: $error');
    return null; // Return null if there was an error
  }
}

Future<void> updateChat(Chat chat) async {
  try {
    if (chat.key.isEmpty) {
      print('Error: Chat key is null');
      return;
    }
    await chatsCollection.doc(chat.key).update(chat.toJson());
    print('Chat updated successfully');
  } catch (error) {
    print('Failed to update Chat: $error');
  }
}

Stream<List<Chat>> getUserChatsStream(String userUid) {
  return chatsCollection
      .where('holdersUid', arrayContains: userUid)
      .snapshots()
      .map((querySnapshot) {
        return querySnapshot.docs.map((doc) {
          return Chat.fromJson({
            ...doc.data() as Map<String, dynamic>,
            'key': doc.id,
          });
        }).toList();
      });
}


Future<void> deleteChat(String chatID) async {
  try {
    await chatsCollection.doc(chatID).delete();
    print('Chat deleted successfully');
  } catch (error) {
    print('Failed to delete Chat: $error');
  }
}

Future<Chat?> getChat(String chatID) async {
  try {
    DocumentSnapshot doc = await chatsCollection.doc(chatID).get();
    if (doc.exists) {
      return Chat.fromJson({
        ...doc.data() as Map<String, dynamic>,
        'key': doc.id,
      });
    }
  } catch (error) {
    print('Failed to fetch chat: $error');
  }
  return null;
}

Future<void> sendMessage(String chatID, Message message) async {
  try {
    DocumentReference chatRef = chatsCollection.doc(chatID);
    await chatRef.update({
      'messages': FieldValue.arrayUnion([message.toMap()]),
      'lastMessage': message.text,
      'timestamp': message.timestamp.toIso8601String(),
    });
    print('Message sent successfully');
  } catch (error) {
    print('Failed to send message: $error');
  }
}

Future<List<Message>> getMessages(String chatID) async {
  try {
    DocumentSnapshot doc = await chatsCollection.doc(chatID).get();
    if (doc.exists) {
      Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
      return (data['messages'] as List<dynamic>?)
              ?.map((e) => Message.fromMap(e))
              .toList() ??
          [];
    }
  } catch (error) {
    print('Failed to fetch messages: $error');
  }
  return [];
}
